# Image search gallery

This is an open source project from [DEV](https://github.com/Narmes/imgBrowser)

- An image search app with angular framework. The app allows users to search for images by entering the search term and hitting enter key and aslo display up to 10 images

## Tech/framework used
1. Angular@14.2.0
2. bootstrap@5.3.2
3. bootstrap-icons

## Installation
```sh
npm run build
```